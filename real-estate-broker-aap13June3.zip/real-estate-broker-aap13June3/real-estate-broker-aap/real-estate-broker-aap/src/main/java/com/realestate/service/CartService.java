package com.realestate.service;
import java.util.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.realestate.dao.CartDao;
import com.realestate.entity.Cart;

@Service
public class CartService {
	@Autowired
	private CartDao cartDao;
	
	public Optional<Cart> getCartProperty(int id) {
		Optional<Cart> cart=null;
		try {
			cart=this.cartDao.findById(id);
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		return cart;
	}
	public List<Cart> getAllCartProperties(){
		return this.cartDao.findAll();
	}
	public Cart setCartProperty(Cart c) {
		return this.cartDao.save(c);
	}
	public void deleteCartProperty(int id){
		this.cartDao.deleteById(id);
	}
	public void updateCartProperty(Cart c,int id) {
		Optional<Cart> optional=this.cartDao.findById(id);
		Cart cart=optional.get();
		c.setCartPropertyId(cart.getCartPropertyId());
		c.setCartPropertyTitle(cart.getCartPropertyTitle());
		c.setCartPropertyDescription(cart.getCartPropertyDescription());
		c.setCartPropertyType(cart.getCartPropertyType());
		c.setCartPropertyPrice(cart.getCartPropertyPrice());
		c.setCartPropertyArea(cart.getCartPropertyArea());
		c.setCartPropertyCity(cart.getCartPropertyCity());
		c.setCartPropertyState(cart.getCartPropertyState());
		c.setCartPath(cart.getCartPath());
		cartDao.save(c);
	}
	public void deleteCartPropertyByID(int id){
		this.cartDao.deleteBycartPropertyId(id);
	}
	
	
	public Cart getPropertyByPrice(int price)
	{
		return cartDao.findBycartPropertyPrice(price);
	}
	
	
	public int getPropertyIdByCartId(int id)
	{
		System.out.println(id);
		System.out.println(cartDao.findBycartPropertyId(id));
		return cartDao.findBycartPropertyId(id);
		
	}
}